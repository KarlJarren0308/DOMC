# DOMC

Web-based Library System for De Ocampo Memorial College

© Copyright 2016 [Karl T. Macadangdang](https://github.com/KarlJarren0308)
