<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Librarians extends Model
{
    protected $table = 'librarians';
}
