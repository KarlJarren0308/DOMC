<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Receives extends Model
{
    protected $table = 'receives';
}
