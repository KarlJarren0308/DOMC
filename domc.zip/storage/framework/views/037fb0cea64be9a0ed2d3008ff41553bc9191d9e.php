<?php $__env->startSection('content'); ?>
    <div class="navbar fixed-top shadow">
        <div class="navbar-content">
            <div class="navbar-element title">De Ocampo Memorial College</div>
            <div class="u-pull-right">
                <a href="<?php echo e(route('main.getOpac')); ?>" class="navbar-element active">OPAC</a>
                <?php if(session()->has('username')): ?>
                    <?php if(session()->get('account_type') == 'Librarian'): ?>
                        <a href="<?php echo e(route('panel.getIndex')); ?>" class="navbar-element">Control Panel</a>
                    <?php endif; ?>

                    <div class="dropdown">
                        <a class="navbar-element dropdown-toggle">
                            <?php if(strlen(session()->get('middle_name')) > 1): ?>
                                <?php echo e(session()->get('first_name') . ' ' . substr(session()->get('middle_name'), 0, 1) . '. ' . session()->get('last_name')); ?>

                            <?php else: ?>
                                <?php echo e(session()->get('first_name') . ' ' . session()->get('last_name')); ?>

                            <?php endif; ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo e(route('main.getLogout')); ?>">Logout</a></li>
                        </ul>
                    </div>
                <?php else: ?>
                    <a href="<?php echo e(route('main.getLogin')); ?>" class="navbar-element">Login</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div id="main-container" class="container">
        <div class="banner">Online Public Access Catalog</div>
        <?php if(session()->has('global_status')): ?>
            <?php if(session()->get('global_status') == 'Success'): ?>
                <?php $class = ' success'; ?>
            <?php elseif(session()->get('global_status') == 'Warning'): ?>
                <?php $class = ' warning'; ?>
            <?php else: ?>
                <?php $class = ' danger'; ?>
            <?php endif; ?>

            <div class="alert<?php echo e($class); ?>"><?php echo e(session()->get('global_message')); ?></div>
        <?php endif; ?>
        <table id="materials-table" class="u-full-width">
            <thead>
                <tr>
                    <th>Call Number</th>
                    <th>Title</th>
                    <th>ISBN</th>
                    <th>Author(s)</th>
                    <th></th>
                </tr>
                <tbody>
                    <?php foreach($works_materials as $material): ?>
                        <?php $isFirst = true; ?>
                        <tr>
                            <td><?php echo e($material->Material_Call_Number); ?></td>
                            <td><?php echo e($material->Material_Title); ?></td>
                            <td><?php echo e($material->Material_ISBN); ?></td>
                            <td>
                                <?php foreach($works_authors as $author): ?>
                                    <?php if($author->Material_ID == $material->Material_ID): ?>
                                        <?php if($isFirst): ?>
                                            <?php $isFirst = false; ?>
                                        <?php else: ?>
                                            <br>
                                        <?php endif; ?>

                                        <?php if(strlen($author->Author_Middle_Name) > 1): ?>
                                            <?php echo e($author->Author_First_Name . ' ' . substr($author->Author_Middle_Name, 0, 1) . '. ' . $author->Author_Last_Name); ?>

                                        <?php else: ?>
                                            <?php echo e($author->Author_First_Name . ' ' . $author->Author_Last_Name); ?>

                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </td>
                            <td class="text-center">
                                <?php if(strlen(session()->has('username'))): ?>
                                    <?php $isReserved = false; ?>
                                    <?php foreach($reservations as $reservation): ?>
                                        <?php if($reservation->Material_ID == $material->Material_ID): ?>
                                            <?php $isReserved = true; ?>
                                            <?php break; ?>
                                        <?php endif; ?>
                                    <?php endforeach; ?>

                                    <?php if($isReserved): ?>
                                        <div class="btn btn-red btn-sm">Already Reserved</div>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('main.getReserve', $material->Material_ID)); ?>" class="btn btn-orange btn-sm">Reserve</a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </thead>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('post_ref'); ?>
    <script src="/js/main.opac.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>