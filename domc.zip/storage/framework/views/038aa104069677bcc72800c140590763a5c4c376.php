<?php $__env->startSection('content'); ?>
    <div class="navbar fixed-top shadow">
        <div class="navbar-content">
            <div class="navbar-element title">De Ocampo Memorial College</div>
            <div class="u-pull-right">
                <a href="<?php echo e(route('main.getOpac')); ?>" class="navbar-element">OPAC</a>
                <?php if(session()->has('username')): ?>
                    <a href="" class="navbar-element">
                        <?php if(strlen(session()->get('middle_name')) > 1): ?>
                            <?php echo e(session()->get('first_name') . ' ' . substr(session()->get('middle_name'), 0, 1) . '. ' . session()->get('last_name')); ?>

                        <?php else: ?>
                            <?php echo e(session()->get('first_name') . ' ' . session()->get('last_name')); ?>

                        <?php endif; ?>
                    </a>
                <?php else: ?>
                    <a href="<?php echo e(route('main.getLogin')); ?>" class="navbar-element active">Login</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div id="main-container" class="container">
        <div class="banner">Login</div>
        <div class="row">
            <div class="three columns">&nbsp;</div>
            <div class="six columns">
                <?php if(session()->has('global_status')): ?>
                    <?php if(session()->get('global_status') == 'Success'): ?>
                        <?php $class = ' success'; ?>
                    <?php elseif(session()->get('global_status') == 'Warning'): ?>
                        <?php $class = ' warning'; ?>
                    <?php else: ?>
                        <?php $class = ' danger'; ?>
                    <?php endif; ?>

                    <div class="alert<?php echo e($class); ?>"><?php echo e(session()->get('global_message')); ?></div>
                <?php endif; ?>
                <?php echo Form::open(array('route' => 'main.postLogin')); ?>

                    <div class="input-block">
                        <?php echo Form::label('username', 'Username:'); ?>

                        <?php echo Form::text('username', null, array('class' => 'u-full-width', 'placeholder' => 'Enter Username Here', 'required' => 'required', 'autofocus' => 'autofocus')); ?>

                    </div>
                    <div class="input-block">
                        <?php echo Form::label('password', 'Password:'); ?>

                        <?php echo Form::password('password', array('class' => 'u-full-width', 'placeholder' => 'Enter Password Here', 'required' => 'required')); ?>

                    </div>
                    <div class="input-block text-right">
                        <?php echo Form::submit('Login', array('class' => 'btn btn-orange')); ?>

                    </div>
                <?php echo Form::close(); ?>

            </div>
            <div class="three columns">&nbsp;</div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>