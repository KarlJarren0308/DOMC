<?php $__env->startSection('content'); ?>
    <div class="navbar fixed-top shadow">
        <div class="navbar-content">
            <div class="navbar-element title">De Ocampo Memorial College</div>
            <div class="u-pull-right">
                <a href="<?php echo e(route('main.getOpac')); ?>" class="navbar-element">OPAC</a>
                <a href="<?php echo e(route('panel.getIndex')); ?>" class="navbar-element active">Control Panel</a>
                <?php if(session()->has('username')): ?>
                    <div class="dropdown">
                        <a class="navbar-element dropdown-toggle">
                            <?php if(strlen(session()->get('middle_name')) > 1): ?>
                                <?php echo e(session()->get('first_name') . ' ' . substr(session()->get('middle_name'), 0, 1) . '. ' . session()->get('last_name')); ?>

                            <?php else: ?>
                                <?php echo e(session()->get('first_name') . ' ' . session()->get('last_name')); ?>

                            <?php endif; ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo e(route('main.getLogout')); ?>">Logout</a></li>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div id="main-container" class="container-fluid">
        <div class="row">
            <div class="three columns">
                <ul class="list-group">
                    <li class="list-group-item"><a href="<?php echo e(route('panel.getIndex')); ?>">Home</a></li>
                    <li class="list-group-item"><a href="<?php echo e(route('panel.getLoan')); ?>">Loan Material(s)</a></li>
                    <li class="list-group-item"><a href="<?php echo e(route('panel.getReserved')); ?>">Reserved Material(s)</a></li>
                    <li class="list-group-item active"><a href="<?php echo e(route('panel.getReceive')); ?>">Receive Material(s)</a></li>
                    <li class="list-group-item"><a href="<?php echo e(route('panel.getManage', 'materials')); ?>">Manage Materials</a></li>
                    <li class="list-group-item"><a href="<?php echo e(route('panel.getManage', 'authors')); ?>">Manage Authors</a></li>
                    <li class="list-group-item"><a href="<?php echo e(route('panel.getManage', 'publishers')); ?>">Manage Publishers</a></li>
                    <li class="list-group-item"><a href="<?php echo e(route('panel.getManage', 'students')); ?>">Manage Students</a></li>
                    <li class="list-group-item"><a href="<?php echo e(route('panel.getManage', 'faculties')); ?>">Manage Faculties</a></li>
                    <li class="list-group-item"><a href="<?php echo e(route('panel.getManage', 'settings')); ?>">System Settings</a></li>
                </ul>
            </div>
            <div class="nine columns">
                <div class="banner">Receive Material(s)</div>
                <?php if(session()->has('global_status')): ?>
                    <?php if(session()->get('global_status') == 'Success'): ?>
                        <?php $class = ' success'; ?>
                    <?php elseif(session()->get('global_status') == 'Warning'): ?>
                        <?php $class = ' warning'; ?>
                    <?php else: ?>
                        <?php $class = ' danger'; ?>
                    <?php endif; ?>

                    <div class="alert<?php echo e($class); ?>"><?php echo e(session()->get('global_message')); ?></div>
                <?php endif; ?>
                <table id="receive-table" class="u-full-width">
                    <thead>
                        <tr>
                            <th>Call Number</th>
                            <th>Title</th>
                            <th>Author(s)</th>
                            <th>Loaned By</th>
                            <th>Penalty</th>
                            <th></th>
                        </tr>
                        <tbody>
                            <?php foreach($loans as $loan): ?>
                                <?php foreach($works_materials as $material): ?>
                                    <?php if($loan->Material_ID == $material->Material_ID): ?>
                                        <?php $isFirst = true; ?>
                                        <tr>
                                            <td><?php echo e($material->Material_Call_Number); ?></td>
                                            <td><?php echo e($material->Material_Title); ?></td>
                                            <td>
                                                <?php foreach($works_authors as $author): ?>
                                                    <?php if($author->Material_ID == $material->Material_ID): ?>
                                                        <?php if($isFirst): ?>
                                                            <?php $isFirst = false; ?>
                                                        <?php else: ?>
                                                            <br>
                                                        <?php endif; ?>

                                                        <?php if(strlen($author->Author_Middle_Name) > 1): ?>
                                                            <?php echo e($author->Author_First_Name . ' ' . substr($author->Author_Middle_Name, 0, 1) . '. ' . $author->Author_Last_Name); ?>

                                                        <?php else: ?>
                                                            <?php echo e($author->Author_First_Name . ' ' . $author->Author_Last_Name); ?>

                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                <?php endforeach; ?>
                                            </td>
                                            <td>
                                                <?php if($loan->Account_Type == 'Faculty'): ?>
                                                    <?php foreach($faculty_accounts as $faculty): ?>
                                                        <?php if($loan->Account_Owner == $faculty->Faculty_ID): ?>
                                                            <?php if(strlen($faculty->Faculty_Middle_Name) > 1): ?>
                                                                <?php echo e($faculty->Faculty_First_Name . ' ' . substr($faculty->Faculty_Middle_Name, 0, 1) . '. ' . $faculty->Faculty_Last_Name); ?>

                                                            <?php else: ?>
                                                                <?php echo e($faculty->Faculty_First_Name . ' ' . $faculty->Faculty_Last_Name); ?>

                                                            <?php endif; ?>

                                                            <?php break; ?>
                                                        <?php endif; ?>
                                                    <?php endforeach; ?>
                                                <?php elseif($loan->Account_Type == 'Librarian'): ?>
                                                    <?php foreach($librarian_accounts as $librarian): ?>
                                                        <?php if($loan->Account_Owner == $librarian->Librarian_ID): ?>
                                                            <?php if(strlen($librarian->Librarian_Middle_Name) > 1): ?>
                                                                <?php echo e($librarian->Librarian_First_Name . ' ' . substr($librarian->Librarian_Middle_Name, 0, 1) . '. ' . $librarian->Librarian_Last_Name); ?>

                                                            <?php else: ?>
                                                                <?php echo e($librarian->Librarian_First_Name . ' ' . $librarian->Librarian_Last_Name); ?>

                                                            <?php endif; ?>

                                                            <?php break; ?>
                                                        <?php endif; ?>
                                                    <?php endforeach; ?>
                                                <?php elseif($loan->Account_Type == 'Student'): ?>
                                                    <?php foreach($student_accounts as $student): ?>
                                                        <?php if($loan->Account_Owner == $student->Student_ID): ?>
                                                            <?php if(strlen($student->Student_Middle_Name) > 1): ?>
                                                                <?php echo e($student->Student_First_Name . ' ' . substr($student->Student_Middle_Name, 0, 1) . '. ' . $student->Student_Last_Name); ?>

                                                            <?php else: ?>
                                                                <?php echo e($student->Student_First_Name . ' ' . $student->Student_Last_Name); ?>

                                                            <?php endif; ?>

                                                            <?php break; ?>
                                                        <?php endif; ?>
                                                    <?php endforeach; ?>
                                                <?php endif; ?>
                                            </td>
                                            <td>Not yet available</td>
                                            <td class="text-center">
                                                <?php if(strlen(session()->has('username'))): ?>
                                                    <?php if($loan->Loan_Status == 'active'): ?>
                                                        <?php echo Form::open(array('route' => 'panel.postLoan', 'class' => 'no-margin')); ?>

                                                            <?php echo Form::hidden('arg0', 'bcfaa2f57da331c29c0bab9f99543451'); ?>

                                                            <?php echo Form::submit('Receive', array('class' => 'btn btn-green btn-sm')); ?>

                                                        <?php echo Form::close(); ?>

                                                    <?php else: ?>
                                                        <div class="btn btn-red btn-sm">Returned</div>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </td>
                                        </tr>

                                        <?php break; ?>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            <?php endforeach; ?>
                        </tbody>
                    </thead>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('post_ref'); ?>
    <script src="/js/panel.receive.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>